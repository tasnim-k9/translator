# Textify — Auth-enabled version
Two folders: server and client.
Run server: cd server && npm install && npm start
Run client: cd client && npm install && npm start (Vite)
Server endpoints:
POST /api/register { username, password }
POST /api/login { username, password }
GET /api/translate?text=...&source=...&target=...
POST /api/history (bearer token)
GET /api/history (bearer token)
