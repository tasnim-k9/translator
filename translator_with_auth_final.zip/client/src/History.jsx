import React, { useEffect, useState } from "react";
export default function History(){
  const [history,setHistory]=useState([]);
  const [error,setError]=useState(null);
  useEffect(()=>{ (async ()=>{ const token=localStorage.getItem("tf_token"); if(!token){ setError("Login to see history"); return; } try{ const resp=await fetch('http://localhost:5000/api/history',{headers:{'Authorization':'Bearer '+token}}); const j=await resp.json(); if(!resp.ok){ setError(j.error||"Error"); } else setHistory(j.history||[]); }catch(e){ setError("Network error"); } })(); },[]);
  return (<div className="card"><h2>History</h2>{error && <div style={{color:'#b00020'}}>{error}</div>}{history.length===0 ? <div className="small">No history yet.</div> : history.map(h=> (<div key={h.id} style={{borderBottom:'1px solid #f0f0f0',padding:'8px 0'}}><div className="small">{new Date(h.ts).toLocaleString()}</div><div><strong>{h.text}</strong></div><div className="small">→ {h.translatedText}</div></div>))}</div>); }