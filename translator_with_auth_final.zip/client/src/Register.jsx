import React, { useState } from "react";
export default function Register(){
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(null);
  async function doRegister(e){
    e.preventDefault(); setError(null);
    try{
      const resp = await fetch('http://localhost:5000/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
      const j = await resp.json();
      if(!resp.ok){ setError(j.error || "Register failed"); return; }
      localStorage.setItem("tf_token", j.token); localStorage.setItem("tf_user", j.username); window.location.href="/translate";
    }catch(e){ setError("Network error"); }
  }
  return (<div className="card"><h2>Register</h2><form onSubmit={doRegister}><input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Choose a username"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Choose a password"/><div className="controls"><button className="btn" type="submit">Register</button></div>{error && <div style={{color:'#b00020'}}>{error}</div>}</form></div>);
}