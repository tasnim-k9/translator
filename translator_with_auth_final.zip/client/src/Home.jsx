import React from "react";
import { Link } from "react-router-dom";
export default function Home(){
  const token = localStorage.getItem("tf_token");
  if(token){
    // if logged in, redirect to translate
    window.location.href = "/translate";
    return null;
  }
  return (
    <div className="card" style={{textAlign:"center", padding:"40px"}}>
      <h1 style={{fontSize:48, margin:0, color:"#6b5876"}}>Textify</h1>
      <p style={{fontStyle:"italic", marginTop:12, fontSize:20, color:"#7b6f74"}}>"Seamless Language Translation at Your Fingertips"</p>
      <div style={{marginTop:24, display:"flex", justifyContent:"center", gap:12}}>
        <Link to="/login" className="btn">Login</Link>
        <Link to="/register" className="btn">Register</Link>
      </div>
    </div>
  );
}