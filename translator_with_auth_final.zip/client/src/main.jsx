import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route, Link, Navigate } from "react-router-dom";
import Translator from "./Translator";
import Login from "./Login";
import Register from "./Register";
import History from "./History";
import "./styles.css";

function ProtectedRoute({children}){
  const token = localStorage.getItem('tf_token');
  if(!token){ window.location.href = '/'; return null; }
  return children;
}

function App(){
  const token = localStorage.getItem("tf_token");
  return (
    <BrowserRouter>
      <nav className="nav">
        <div className="brand">Textify</div>
        <div className="links">{token ? <><Link to="/translate">Translate</Link><Link to="/about">About</Link><Link to="/history">History</Link><a href="#" onClick={()=>{localStorage.removeItem("tf_token"); localStorage.removeItem("tf_user"); window.location.href="/";}}>Logout</a></> : <><Link to="/login">Login</Link><Link to="/register">Register</Link></>}</div>
      </nav>
      <main className="main">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/translate" element={<ProtectedRoute><Translator/></ProtectedRoute>} />
          <Route path="/about" element={<ProtectedRoute><About/></ProtectedRoute>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Register/>} />
          <Route path="/history" element={<ProtectedRoute><History/></ProtectedRoute>} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root")).render(<App/>);
export default App;
