import React from "react";
export default function About(){
  return (
    <div className="card" style={{lineHeight:1.6}}>
      <h2 style={{color:"#6b5876", marginTop:0}}>About Textify</h2>
      <p style={{fontSize:16}}>Textify is an intelligent text translation platform designed to break language barriers. It uses a free translation API with support for over 100 languages.</p>
      <h3 style={{color:"#6b5876"}}>Key features:</h3>
      <ul style={{fontSize:16}}>
        <li>Auto language detection</li>
        <li>Speech-to-text input</li>
        <li>Text-to-speech output</li>
        <li>Copy &amp; download translations</li>
        <li>Responsive and accessible design</li>
      </ul>
    </div>
  );
}