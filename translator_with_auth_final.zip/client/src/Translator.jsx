import React, { useState } from "react";
const LANGS = [{code:"auto",label:"Detect Automatically"},{code:"en",label:"English"},{code:"hi",label:"Hindi"},{code:"es",label:"Spanish"},{code:"fr",label:"French"},{code:"de",label:"German"}];
export default function Translator(){
  const [text,setText]=useState("");
  const [translated,setTranslated]=useState("");
  const [source,setSource]=useState("auto");
  const [target,setTarget]=useState("hi");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState(null);

  async function doTranslate(saveHistory=true){
    setError(null); setTranslated(""); if(!text.trim()){ setError("Enter text"); return; }
    if(source===target){ setError("Source and target must differ"); return; }
    setLoading(true);
    try{
      const token = localStorage.getItem("tf_token");
      const url = `/api/translate?text=${encodeURIComponent(text)}&source=${encodeURIComponent(source)}&target=${encodeURIComponent(target)}`;
      const resp = await fetch(url.replace(/^\/+/,'http://localhost:5000/'));
      const j = await resp.json();
      if(!resp.ok){ setError(j.error || "API error"); setLoading(false); return; }
      setTranslated(j.translatedText || "");
      // save to history if logged in
      if(saveHistory && token && j.translatedText){
        await fetch('http://localhost:5000/api/history', { method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body:JSON.stringify({ text, translatedText:j.translatedText, source:j.source, target:j.target }) });
      }
    }catch(e){ console.error(e); setError("Network error"); }
    setLoading(false);
  }

  function copyTxt(){ navigator.clipboard.writeText(translated); alert("Copied"); }
  function downloadTxt(){ const a=document.createElement('a'); const blob=new Blob([translated],{type:'text/plain'}); a.href=URL.createObjectURL(blob); a.download='translation.txt'; a.click(); }
  function speak(){ if(!translated) return; const u=new SpeechSynthesisUtterance(translated); u.lang=target; speechSynthesis.speak(u); }

  return (
    <div className="card">
      <h2>Textify — Translator</h2>
      <div className="row">
        <select value={source} onChange={e=>setSource(e.target.value)}>{LANGS.map(l=> <option key={l.code} value={l.code}>{l.label}</option>)}</select>
        <button className="btn" onClick={()=>{ const s=source; setSource(target); setTarget(s); }}>Swap</button>
        <select value={target} onChange={e=>setTarget(e.target.value)}>{LANGS.filter(l=>l.code!=="auto").map(l=> <option key={l.code} value={l.code}>{l.label}</option>)}</select>
      </div>
      <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Type text here..."></textarea>
      <div className="controls">
        <button className="btn" onClick={()=>doTranslate(true)} disabled={loading}>{loading? "Translating..." : "Translate"}</button>
        <button className="btn" onClick={()=>{ setText(''); setTranslated(''); }}>Clear</button>
      </div>
      {error && <div style={{color:'#b00020',marginTop:8}}>{error}</div>}
      <textarea value={translated} readOnly placeholder="Translation appears here"></textarea>
      <div className="controls" style={{marginTop:8}}>
        <button className="btn" onClick={copyTxt}>Copy</button>
        <button className="btn" onClick={downloadTxt}>Download</button>
        <button className="btn" onClick={speak}>Listen</button>
      </div>
    </div>
  );
}