import React, { useState } from "react";
export default function Login(){
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(null);
  async function doLogin(e){
    e.preventDefault(); setError(null);
    try{
      const resp = await fetch('http://localhost:5000/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
      const j = await resp.json();
      if(!resp.ok){ setError(j.error || "Login failed"); return; }
      localStorage.setItem("tf_token", j.token); localStorage.setItem("tf_user", j.username); window.location.href="/translate";
    }catch(e){ setError("Network error"); }
  }
  return (<div className="card"><h2>Login</h2><form onSubmit={doLogin}><input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password"/><div className="controls"><button className="btn" type="submit">Login</button></div>{error && <div style={{color:'#b00020'}}>{error}</div>}</form></div>);
}